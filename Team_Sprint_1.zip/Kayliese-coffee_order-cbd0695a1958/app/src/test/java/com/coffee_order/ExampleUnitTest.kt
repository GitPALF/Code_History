package com.coffee_order

import android.widget.Button
import com.coffee_order.objects.ItemSize
import com.coffee_order.objects.models.FoodItemModel
import org.junit.Test

import org.junit.Assert.*
import java.math.BigDecimal

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class ExampleUnitTest {

    @Test
    fun foodItemModelers_isCorrect()
    {
        val _1 = FoodItemModel("Hot Coffee", BigDecimal("5"), ItemSize.LARGE, "Latte", 1, R.id.backFloatingActionButton)
        val _2 = FoodItemModel("Hot Coffee", BigDecimal("5"), ItemSize.LARGE, "Latte", 1, R.id.backFloatingActionButton)

        assertEquals(_1, _2)

        val _3 = FoodItemModel("Ho Coffee", BigDecimal("5"), ItemSize.LARGE, "Latte", 1, R.id.backFloatingActionButton)
        val _4 = FoodItemModel("Hot Coffee", BigDecimal("5"), ItemSize.LARGE, "Latte", 1, R.id.backFloatingActionButton)

        assertNotEquals(_3, _4)
    }


    @Test
    fun checkoutTotal_isCorrect()
    {

        val sum = listOf(
            FoodItemModel("Hot Coffee", BigDecimal("5"), ItemSize.LARGE, "Latte", 1, R.id.backFloatingActionButton),
            FoodItemModel("Hot Coffee", BigDecimal("5"), ItemSize.LARGE, "Latte", 1, R.id.backFloatingActionButton),
            FoodItemModel("Hot Coffee", BigDecimal("5"), ItemSize.LARGE, "Latte", 1, R.id.backFloatingActionButton),
            FoodItemModel("Hot Coffee", BigDecimal("5"), ItemSize.LARGE, "Latte", 1, R.id.backFloatingActionButton)
        ).sumOf { it.itemPrice.multiply(BigDecimal(it.quantity))}

        assertEquals(sum, BigDecimal(20))
    }

    @Test
    fun checkOutQuantity_isCorrect()
    {
        val sum = listOf(
            FoodItemModel("Hot Coffee", BigDecimal("5"), ItemSize.LARGE, "Latte", 30, R.id.backFloatingActionButton),
            FoodItemModel("Hot Coffee", BigDecimal("5"), ItemSize.LARGE, "Latte", 50, R.id.backFloatingActionButton),
            FoodItemModel("Hot Coffee", BigDecimal("5"), ItemSize.LARGE, "Latte", 10, R.id.backFloatingActionButton),
            FoodItemModel("Hot Coffee", BigDecimal("5"), ItemSize.LARGE, "Latte", 10, R.id.backFloatingActionButton)
        ).sumOf { it.quantity }

        assertEquals(sum, 100)
    }


    @Test
    fun itemSizes_isCorrect()
    {
        assertEquals(ItemSize.EMPTY.size, "")
        assertEquals(ItemSize.SMALL.size, "S")
        assertEquals(ItemSize.MEDIUM.size, "M")
        assertEquals(ItemSize.LARGE.size, "L")
        assertEquals(ItemSize.EXTRA_LARGE.size, "XL")
    }



}