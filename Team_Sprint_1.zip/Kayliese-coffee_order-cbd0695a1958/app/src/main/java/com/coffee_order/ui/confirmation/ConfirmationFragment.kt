package com.coffee_order.ui.confirmation


import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.coffee_order.R
import com.coffee_order.databinding.FragmentConfirmationBinding
import com.coffee_order.databinding.FragmentProfileBinding

class ConfirmationFragment : Fragment() {

    private var _binding: FragmentConfirmationBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        val view = inflater.inflate(R.layout.fragment_confirmation, container, false)


        val returnBtn = view.findViewById(R.id.confirmationButton) as ImageButton
        returnBtn.setOnClickListener(returnBtnClicked())

        return view
    }

    private fun returnBtnClicked(): View.OnClickListener
        = View.OnClickListener {
           findNavController().navigate(R.id.action_navigation_confirmation_to_navigation_home)
    }
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}