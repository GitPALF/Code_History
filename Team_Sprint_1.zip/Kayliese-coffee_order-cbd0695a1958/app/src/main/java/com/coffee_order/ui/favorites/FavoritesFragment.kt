package com.coffee_order.ui.favorites

import android.os.Bundle
import android.view.*
import android.widget.ListView
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.coffee_order.R
import com.coffee_order.databinding.FragmentFavoritesBinding
import com.coffee_order.objects.ItemSize
import com.coffee_order.objects.adapter.FoodItemAdapter
import com.coffee_order.objects.models.FoodItemModel
import java.math.BigDecimal

class FavoritesFragments : Fragment() {

    private var _binding: FragmentFavoritesBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_favorites, container, false)
        val imageList = arrayOf(
            R.drawable.pngwing_com_1,
            R.drawable.image_4,
            R.drawable.luwak,

            )

        val items: MutableList<FoodItemModel> = mutableListOf(
            FoodItemModel("Espresso with steamed milk", BigDecimal("7"), ItemSize.LARGE, "Latte",  1,imageList[0]),
            FoodItemModel("Toasted Everything Bagel", BigDecimal("5"), ItemSize.MEDIUM, "Bagel", 1, imageList[1]),
            FoodItemModel("Hot Coffee", BigDecimal("5"), ItemSize.SMALL, "Luwak Coffee", 1, imageList[2])
        )

        val listView = view.findViewById(R.id.favListView) as ListView
        listView.adapter = FoodItemAdapter(
            requireActivity(),
            R.layout.favs_view_layout,
            items,
            false, false
        )

        return view
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(false)
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.next_menu, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.next_forward -> {
                findNavController().navigate(R.id.action_dashboard_to_notifications)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}