package com.coffee_order.ui.orderH

import androidx.fragment.app.Fragment
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.coffee_order.ui.cart.CartViewModel

class OrderHistoryViewModel : ViewModel() {
    private val _text = MutableLiveData<String>().apply {
        value = "This is the Order History Screen"
    }
    val text: LiveData<String> = _text
}