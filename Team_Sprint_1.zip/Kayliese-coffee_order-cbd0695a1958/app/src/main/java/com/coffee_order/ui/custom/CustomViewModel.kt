package com.coffee_order.ui.custom

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class CustomViewModel : ViewModel() {


    private val _text = MutableLiveData<String>().apply {
        value = "This is customization page"
    }
    val text: LiveData<String> = _text
    
}
