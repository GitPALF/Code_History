package com.coffee_order.objects

enum class ItemSize(val size: String) {
    EMPTY(""),
    SMALL("S"),
    MEDIUM("M"),
    LARGE("L"),
    EXTRA_LARGE("XL")
}