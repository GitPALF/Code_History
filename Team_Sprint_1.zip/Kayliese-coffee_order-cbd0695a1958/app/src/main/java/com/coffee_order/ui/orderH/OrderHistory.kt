package com.coffee_order.ui.orderH

import android.os.Bundle
import android.view.*
import android.widget.Button
import android.widget.ListView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.coffee_order.R
import com.coffee_order.databinding.OrderHistoryFragmentBinding
import com.coffee_order.ext.parseNumbersWithCommas
import com.coffee_order.objects.ItemSize
import com.coffee_order.objects.adapter.FoodItemAdapter
import com.coffee_order.objects.models.FoodItemModel
import com.coffee_order.ui.cart.CartFragment
import java.math.BigDecimal
import java.text.SimpleDateFormat
import java.util.*

class OrderHistory : Fragment() {

    private var _binding: OrderHistoryFragmentBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        val view = inflater.inflate(R.layout.order_history_fragment, container, false)
        val imageList = arrayOf(
            R.drawable.image_4,
            R.drawable.pngwing_com_1,
            R.drawable.luwak,
            R.drawable.muffin,
            R.drawable.cappuccino,
            R.drawable.image_1,

            )
        val items: MutableList<FoodItemModel> = mutableListOf(
            FoodItemModel("Hot Coffee", BigDecimal("5"), ItemSize.LARGE, "Latte", 1, imageList[1]),
            FoodItemModel("Food Item", BigDecimal("5"), ItemSize.MEDIUM, "Bagel", 5, imageList[0]),
            FoodItemModel("Hot Coffee", BigDecimal("8"), ItemSize.LARGE, "Cappuccino", 5, imageList[4]),
            FoodItemModel("Food Item", BigDecimal("8"), ItemSize.EMPTY, "Muffin", 2, imageList[3]),

            )

        val listView = view.findViewById(R.id.CartListView) as ListView
        FoodItemAdapter(
            context = requireActivity(),
            resource = R.layout.order_view_layout,
            items,
            isCartPage = false,
            isHistoryPage = true
        ).also { listView.adapter = it }

        return view
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

}