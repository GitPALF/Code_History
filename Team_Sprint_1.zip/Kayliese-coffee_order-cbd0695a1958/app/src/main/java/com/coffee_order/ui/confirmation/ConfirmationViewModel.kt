package com.coffee_order.ui.confirmation

import androidx.lifecycle.ViewModel

class ConfirmationViewModel : ViewModel() {
}