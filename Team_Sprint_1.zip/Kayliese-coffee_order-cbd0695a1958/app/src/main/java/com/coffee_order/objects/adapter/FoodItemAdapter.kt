package com.coffee_order.objects.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.coffee_order.R
import com.coffee_order.ext.parseNumbersWithCommas
import com.coffee_order.objects.models.FoodItemModel
import com.coffee_order.ui.orderH.OrderHistory
import com.coffee_order.ui.orderH.OrderHistoryViewModel
import java.math.BigDecimal

class FoodItemAdapter(
    context: Context,
    resource: Int,
    private val objects: MutableList<FoodItemModel>,
    private val isCartPage: Boolean,
    private val isHistoryPage: Boolean,
    private var mContext: Context = context,
    private var mResource: Int = resource,
) : ArrayAdapter<FoodItemModel>(context, resource, objects)
{

    private val TAG = "COFFEE_APP"

    fun getCheckoutSum() = objects.sumOf { it.itemPrice.multiply(BigDecimal(it.quantity)) }
    fun getCartTotal() =  objects.sumOf { it.quantity }


    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View
    {

        // ? indicates that that method call could return a nullable object, in kotlin all items are non-null by default.
        // If you know something could be null you can notate the object with a question mark like this: String? -> this will say that this string could be null
        // If you see a ? mark in a method change you can handle the null using the elvis operation (?:) this will do what ever its told if the left side AT ANY POINT returns null
        // Example string?.anotherString?.anotherAnotherString ?: "NULL STRING IN THE CHAIN"
        val type = getItem(position)?.itemType ?: throw IllegalStateException("Could not get type at current position")
        val price = getItem(position)?.itemPrice ?: throw IllegalStateException("Could not get price at current position")
        val size = getItem(position)?.itemSize ?: throw IllegalStateException("Could not get size at current position")
        val name = getItem(position)?.itemName ?: throw IllegalStateException("Could not get name at current position")
        var quantity = getItem(position)?.quantity ?: throw IllegalStateException("Could not get quantity at current position ")
        val picture = getItem(position)?.pictureID ?: throw IllegalStateException("Could not pictureID at current position ")


        val inflater = LayoutInflater.from(mContext)
        // bad practice
        val view: View = inflater.inflate(mResource, parent, false)
        // Java Equivalent = final View view = inflater.inflate();

        val tvType = view.findViewById(R.id.ItemType) as TextView
        // as is just casting, Java Equivalent = final TextView tvType = (TextView) view.findViewById(R.id.ItemType);
        val tvPrice = view.findViewById(R.id.ItemPrice) as TextView
        val tvSize = view.findViewById(R.id.ItemSize) as TextView
        val tvQuantity = view.findViewById(R.id.ItemQuantity) as TextView
        val tvName = view.findViewById(R.id.ItemName) as TextView
        val tvPicture = view.findViewById(R.id.FoodImageView) as ImageView

        if (isCartPage || isHistoryPage) {
            val addButton = view.findViewById(R.id.QuantityAddButton) as Button
            val subtractButton = view.findViewById(R.id.QuantitySubButton) as Button
            addButton.setOnClickListener {
                objects[position].quantity++
                quantity = quantity.inc()
                tvQuantity.text = quantity.toString()


            }

            subtractButton.setOnClickListener {
                if (quantity.dec() == 0) {
                    val itemRemoving = getItem(position)
                        ?: throw IllegalStateException("Could not find object at position $position")
                    objects.remove(itemRemoving)
                    notifyDataSetChanged()
                    return@setOnClickListener
                }
                objects[position].quantity--
                quantity = quantity.dec()
                tvQuantity.text = quantity.toString()
            }
        }


        tvType.text = type
        tvName.text = name
        tvPrice.text = "$${price.parseNumbersWithCommas()}"
        tvSize.text = size.size
        tvQuantity.text = quantity.toString()



        tvPicture.setImageResource(picture)
        return view
    }





}