package com.coffee_order.ui.cart

import android.app.AlertDialog
import android.os.Bundle
import android.view.*
import android.widget.Button
import android.widget.ListView
import android.widget.Spinner
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.coffee_order.R
import com.coffee_order.databinding.FragmentCartBinding
import com.coffee_order.ext.parseNumbersWithCommas
import com.coffee_order.objects.ItemSize
import com.coffee_order.objects.adapter.FoodItemAdapter
import com.coffee_order.objects.models.FoodItemModel
import com.coffee_order.ui.orderH.OrderHistory
import java.math.BigDecimal

class CartFragment : Fragment() {

    private var _binding: FragmentCartBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Create view
        val view = inflater.inflate(R.layout.fragment_cart, container, false)
        val imageList = arrayOf(
            R.drawable.image_4,
            R.drawable.pngwing_com_1,
            R.drawable.luwak,
            R.drawable.muffin,
            R.drawable.cappuccino,
            R.drawable.image_1,

            )
        val items: MutableList<FoodItemModel> = mutableListOf(
            FoodItemModel("Hot Coffee", BigDecimal("5"), ItemSize.LARGE, "Latte", 1, imageList[1]),
            FoodItemModel("Food Item", BigDecimal("5"), ItemSize.EMPTY, "Bagel", 5, imageList[0]),
            FoodItemModel("Hot Coffee", BigDecimal("8"), ItemSize.LARGE, "Cappuccino", 5, imageList[4]),
            FoodItemModel("Food Item", BigDecimal("8"), ItemSize.EMPTY, "Muffin", 2, imageList[3]),

            )

        val listView = view.findViewById(R.id.CartListView) as ListView
        listView.adapter = FoodItemAdapter(
            requireActivity(),
            R.layout.cart_view_layout,
            items,
            true,
            false
        )

        val checkoutButton = view.findViewById(R.id.OrderConfirmedButton) as Button
        checkoutButton.setOnClickListener(checkoutButtonClicked(listView.adapter as FoodItemAdapter))


        return view

    }

    private fun checkoutButtonClicked(items: FoodItemAdapter): View.OnClickListener
        = View.OnClickListener {

        val total = items.getCheckoutSum().parseNumbersWithCommas()
        val cartItemsTotal = items.getCartTotal()
        val hour = view?.findViewById(R.id.HoursSpinner) as Spinner
        val minutes = view?.findViewById(R.id.MinutesSpinner) as Spinner
        val amOrPm = view?.findViewById(R.id.AMorPMSpinner) as Spinner


        val builder = AlertDialog.Builder(context,R.style.AlertDialogTheme)
                builder.setTitle("Are you sure you would like to checkout?")
                builder.setMessage("""
                    Your cart has $cartItemsTotal items
                    Your total is $$total USD
                    Your Pickup Time is ${hour.selectedItem}:${minutes.selectedItem}${amOrPm.selectedItem}
                """.trimIndent())
                builder.setPositiveButton(
                    "Checkout!"
                ) { _, _ -> findNavController().navigate(R.id.navigation_confirmation) }
                builder.setNegativeButton("Go back", null)
                builder.setIcon(android.R.drawable.ic_dialog_alert)
                builder.show()


    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }



    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.next_menu, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.next_forward -> {
                findNavController().navigate(R.id.action_notifications_to_profile)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}