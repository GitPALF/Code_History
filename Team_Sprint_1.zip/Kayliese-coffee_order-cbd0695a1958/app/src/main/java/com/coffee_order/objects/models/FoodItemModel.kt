package com.coffee_order.objects.models

import com.coffee_order.objects.ItemSize
import java.math.BigDecimal

// Data classes in kotlin generate an equals and hashcode method by default
// All classes in kotlin automatically have getters and setters
// You can access them by doing the following
/*
    val food = FoodItemModel();

    // Getter
    val name = food.name

    // Setter (this is a val so you cant reassign it but this is an example)
    food.name = "another food"
 */
data class FoodItemModel(
    // Classes in kotlin are all final by default
    // Using var is usually bad practice. Only use var if the value needs to 100% change.
    val itemType: String,
    val itemPrice: BigDecimal,
    val itemSize: ItemSize,
    val itemName: String,
    var quantity: Int,
    val pictureID: Int
    )

