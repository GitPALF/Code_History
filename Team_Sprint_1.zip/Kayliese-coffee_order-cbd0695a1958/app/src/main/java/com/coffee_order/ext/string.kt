package com.coffee_order.ext

import java.math.BigDecimal
import java.text.DecimalFormat


fun BigDecimal.parseNumbersWithCommas() = DecimalFormat("#,###.00").format(this).toString()
