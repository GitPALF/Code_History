package com.coffee_order.ui.custom

import android.os.Bundle
import android.view.*
import android.widget.Button
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.coffee_order.R
import com.coffee_order.databinding.FragmentCustomBinding
import com.google.android.material.floatingactionbutton.FloatingActionButton

private val MenuItem.backFloatingActionButton: Any
    get() = Unit

class CustomFragment : Fragment() {

    private var _binding: FragmentCustomBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    companion object {
        fun newInstance() = CustomFragment()
    }

    private lateinit var viewModel: CustomViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_custom, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val x = view.findViewById(R.id.addToCartButton) as Button
        val z = view.findViewById(R.id.backFloatingActionButton) as FloatingActionButton

        x.setOnClickListener(goBackHome())
        z.setOnClickListener(goBackHome())

    }

    private fun goBackHome() = View.OnClickListener {
        findNavController().navigate(R.id.action_customFragment_back_to_navigation_dashboard)
    }






    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(false)
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.next_menu, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.backFloatingActionButton) {
            R.id.next_forward -> {
                findNavController().navigate(R.id.action_customFragment_back_to_navigation_dashboard)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this)[CustomViewModel::class.java]
        // TODO: Use the ViewModel
    }

}