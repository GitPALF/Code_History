package com.coffee_order

import android.os.Bundle
import com.google.android.material.bottomnavigation.BottomNavigationView
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.NavController
import androidx.navigation.findNavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.NavigationUI
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.coffee_order.databinding.ActivityMainBinding
import java.lang.IllegalStateException

class MainActivity : AppCompatActivity() {

    /**
     * What is an activity:
     * A single screen in the app
     *
     * What is a view:
     * Single element in your activity
     *  Ex: TextViews, Buttons
     *
     *  For example:
     *   A activity will have many views (i.e may buttons, textbooks and views etc)
     *
     * What are Lifecycle Functions:
     *  Its basically state on what happens in the app
     *
     *  For example:
     *      onCreate - Will do whatever is inside of the code block when that Activity is created
     *      onDestroy - .............. ............................................... is destroyed
     *  There are many more but you get the point
     *
     *  Res Folder is for:
     *      - Resources (lol)
     *      - Images
     *      - Theme Colors
     *      Used for declaring project wide things
     *
     *  What is gradle:
     *      Gradle is build engine for JVM languages (Java, Kotlin, Groovy)
     *      Used for building, testing, and turning your project into a jar
     *      If you open build.gradle you add dependencies, plugins, etc
     *
     *      Want to add a dependency?
     *          Gradle uses a system called the acronym stands for GroupId-Artifact-Version
     *              Example:     implementation 'org.postgresql:postgresql:42.3.1'
     *              This may look confused but its rather simple. It may be a bit easier to explain this if you look at an example
     *              If you goto this link https://mvnrepository.com/ and search for a repository of something cool click it on it, click a version, and then
     *              you should see something that says 'Maven'.
     *
     *
     *              You may see something like this:
     *              <!-- https://mvnrepository.com/artifact/hu.simplexion.zakadabar/core-js -->
                    <dependency>
                    <groupId>hu.simplexion.zakadabar</groupId>
                    <artifactId>core-js</artifactId>
                    <version>2022.2.14</version>
                    <type>pom</type>
                    <scope>runtime</scope>
                    </dependency>

                    You may notice that they have the items we need for our GAV system.

                    to convert this into a gradle dependcy just do the following
                    implementation 'hu.simplexion.zakadabar:core-js:2022.2.14'
                                                  <groupid>:artifcat:version

                    ITS as easy as that and you can add libraries to make the project easier as  you see fit

     *
     *
     */


    private lateinit var binding: ActivityMainBinding
    private var controller: NavController? = null
    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbarMain.root)

        val navHostFragment =
            (supportFragmentManager.findFragmentById(R.id.nav_host_fragment_activity_main) as NavHostFragment?)!!
        controller = navHostFragment.navController
        val control = controller ?: throw IllegalStateException("Controller could not be accessed because it is null")

        // Used for removing back arrow
        val appBarConfiguration = AppBarConfiguration(setOf(
            R.id.navigation_home, R.id.navigation_notifications, R.id.navigation_dashboard, R.id.navigation_profile, R.id.navigation_orderHistory
        ))
        NavigationUI.setupActionBarWithNavController(this, control, appBarConfiguration)

        binding.navView.setupWithNavController(control)
    }

    /* Supports back button navigation
    Use navigation, which makes a stack automatically
    so when you press the back button page
    it goes back in the order it was triggered or opened
    */
  /*  override fun onSupportNavigateUp(): Boolean =
        controller?.navigateUp() ?:
        throw IllegalStateException("An unexpected error has occurred while attempting to use the controller")*/
}