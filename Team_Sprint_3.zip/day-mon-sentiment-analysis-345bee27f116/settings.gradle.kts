rootProject.name = "sentiment-analysis"

