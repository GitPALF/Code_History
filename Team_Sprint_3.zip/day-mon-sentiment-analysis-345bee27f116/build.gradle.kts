plugins {
    id("java")
}

group = "edu.pitt.upj"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()

}

dependencies {
    implementation("com.fasterxml.jackson.core:jackson-databind:2.13.2.2")
    implementation("org.junit.jupiter:junit-jupiter:5.8.1")
    testImplementation("org.junit.jupiter:junit-jupiter-api:5.8.2")
    testRuntimeOnly("org.junit.jupiter:junit-jupiter-engine:5.8.2")
    implementation("org.jsoup:jsoup:1.14.3")
    implementation("ch.qos.logback:logback-classic:1.2.11")
    implementation("com.squareup.okhttp3:okhttp:4.9.3")
    implementation("com.itextpdf:itextpdf:5.5.13.2")

    // https://mvnrepository.com/artifact/software.amazon.awssdk/bom
   // runtimeOnly("software.amazon.awssdk:bom:2.17.164")

    implementation("com.amazonaws:aws-java-sdk-s3:1.12.193")
    implementation("com.amazonaws:aws-java-sdk-comprehend:1.12.196")
}

tasks.getByName<Test>("test") {
    useJUnitPlatform()
}