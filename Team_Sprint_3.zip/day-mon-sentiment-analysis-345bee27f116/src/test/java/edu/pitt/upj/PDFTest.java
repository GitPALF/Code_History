package edu.pitt.upj;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfWriter;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class PDFTest {
    @Test
    void createAndDeleteFile() throws IOException
    {
        LocalDate reportDate = LocalDate.now();
        File file = new File("PDFs\\"+ reportDate + ".pdf");
        assertTrue(file.createNewFile());
        assertTrue(file.delete());
    }

   // write pdf unit test
    @Test
    void writePDF() throws IOException, DocumentException
    {
        var document = new Document();
        var writer = PdfWriter.getInstance(document, new FileOutputStream("PDF.pdf"));
        assertNotNull(document);


        document.open();
        assertTrue(document.isOpen());

        var font = new Font(Font.FontFamily.TIMES_ROMAN,14.0f,3, BaseColor.BLUE);
        var title = new Paragraph("Sentiment report test");
        document.add(title);
        var chunk = new Chunk("This is a test", font);
        chunk.setFont(font);
        document.add(chunk);

        document.close();
        writer.close();
        assertFalse(document.isOpen());
        assertTrue(new File("PDF.pdf").delete());
    }


}
