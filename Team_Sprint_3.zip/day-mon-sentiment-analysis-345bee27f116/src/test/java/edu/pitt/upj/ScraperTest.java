package edu.pitt.upj;

import edu.pitt.upj.objects.scraper.Scraper;
import edu.pitt.upj.objects.scraper.ScraperDTO;
import edu.pitt.upj.objects.scraper.scrapers.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.List;

class ScraperTest
{
    // write test cases here
    @Test
    void testScraping()
    {
        var scraper = new DummyScraper();
        var info = scraper.scrape();

        Assertions.assertEquals("THIS IS AN EXAMPLE", info.get(0).data());
        Assertions.assertEquals("https://schoolbot.dev", info.get(0).url());
    }

    // test reddit scrapper
    @Test
    void testRedditScraping()
    {
        var scraper = new RedditScraper();
        var info = scraper.scrape();

        Assertions.assertNotEquals(info, List.of());
        Assertions.assertEquals(scraper.getScrapeUrl(), info.get(0).url());
    }

    // test tribune scrapper
    @Test
    void testTribuneScraping()
    {
        var scraper = new TribuneScraper();
        var info = scraper.scrape();

        Assertions.assertNotEquals(info, List.of());
        Assertions.assertEquals(scraper.getScrapeUrl(), info.get(0).url());
    }

    // test pitt scrapper
    @Test
    void testPittScraping()
    {
        var scraper = new PittScraper();
        var info = scraper.scrape();

        Assertions.assertNotEquals(info, List.of());
        Assertions.assertEquals(scraper.getScrapeUrl(), info.get(0).url());
    }

    // test yahoo scraper
    @Test
    void testYahooScraping()
    {
        var scraper = new YahooScraper();
        var info = scraper.scrape();

        Assertions.assertNotEquals(info, List.of());
        Assertions.assertEquals(scraper.getScrapeUrl(), info.get(0).url());
    }

    // test niche scraper
    @Test
    void testNicheScraping()
    {
        var scraper = new NicheScraper();
        var info = scraper.scrape();

        Assertions.assertNotEquals(info, List.of());
        Assertions.assertEquals(scraper.getScrapeUrl(), info.get(0).url());
    }

    // test ratemyprofessor scraper
    @Test
    void testRatemyprofessorScraping()
    {
        var scraper = new RateMyProfessorScraper();
        var info = scraper.scrape();

        Assertions.assertNotEquals(info, List.of());
        Assertions.assertEquals(scraper.getScrapeUrl(), info.get(0).url());
    }

    // test wtaj scraper
    @Test
    void testWtajScraping()
    {
        var scraper = new WTAJScraper();
        var info = scraper.scrape();

        Assertions.assertNotEquals(info, List.of());
        Assertions.assertEquals(scraper.getScrapeUrl(), info.get(0).url());
    }

    // test student review scraper
    @Test
    void testStudentReviewScraping()
    {
        var scraper = new StudentsReviewScraper();
        var info = scraper.scrape();

        Assertions.assertNotEquals(info, List.of());
        Assertions.assertEquals(scraper.getScrapeUrl(), info.get(0).url());
    }


    private class DummyScraper extends Scraper
    {
        protected DummyScraper() {
            super("https://schoolbot.dev");
            this.jsonUrl = getScrapeUrl();
        }

        @Override
        public List<ScraperDTO> scrape()
        {
            var body = this.getBody();
            if (body == null) return List.of();
            return List.of(new ScraperDTO(this.getScrapeUrl(), body));
        }
    }
}
