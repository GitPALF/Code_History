
package edu.pitt.upj;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.comprehend.AmazonComprehend;
import com.amazonaws.services.comprehend.AmazonComprehendClientBuilder;
import com.amazonaws.services.comprehend.model.DetectKeyPhrasesRequest;
import com.amazonaws.services.comprehend.model.DetectSentimentRequest;
import com.amazonaws.services.comprehend.model.LanguageCode;
import edu.pitt.upj.handlers.ConfigHandler;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import java.io.*;
import java.util.*;


@TestInstance(TestInstance.Lifecycle.PER_METHOD)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class SentimentTest
{
    private static AmazonComprehend client;
    private static final Regions REGION = Regions.US_WEST_2;
    private static final String text = "Amazon.com, Inc. is located in Seattle, WA and was founded July 5th, 1994 by Jeff Bezos, allowing customers to buy everything from books to blenders. Seattle is north of Portland and south of Vancouver, BC. Other notable Seattle - based companies are Starbucks and Boeing" ;

    @BeforeAll
    public static void setUp() throws IllegalArgumentException
    {

        var config = ConfigHandler.getInstance().getConfig();

        var privateKey = config.privateKey();

        if (privateKey == null || privateKey.equals(""))
           privateKey =  System.getenv("PRIVATE_KEY");

        if (privateKey == null || privateKey.equals(""))
            throw new IllegalArgumentException("Private Key is not set");


        var publicKey = config.publicKey();

        if (publicKey == null || publicKey.equals(""))
           publicKey =  System.getenv("PUBLIC_KEY");

        if (publicKey == null || publicKey.equals(""))
            throw new IllegalArgumentException("No public key found");

        // Run tests on Real AWS Resources
        client = AmazonComprehendClientBuilder.standard()
                .withCredentials(new AWSStaticCredentialsProvider(new BasicAWSCredentials(publicKey, privateKey)))
                .withRegion(REGION)
                .build();

        assertNotNull(client);
    }

    // Client Test
    @Test
    @Order(1)
     void whenInitializingAWSService_thenNotNull()
    {
        assertNotNull(client);
        System.out.println("Test 1 passed");
    }

    // Sentiment Test
    @Test
    @Order(2)
    void detectSentiment()
    {
        assertDoesNotThrow(() -> client.detectSentiment(new DetectSentimentRequest().withText(text).withLanguageCode(LanguageCode.En)));
        System.out.println("Test 2 passed");
    }

    // Key Phrases Test
    @Test
    @Order(3)
    void detectKeyPhrases()
    {
       assertDoesNotThrow(() -> client.detectKeyPhrases(new DetectKeyPhrasesRequest().withText(text).withLanguageCode(LanguageCode.En)));
       System.out.println("Test 3 passed");
    }

}
