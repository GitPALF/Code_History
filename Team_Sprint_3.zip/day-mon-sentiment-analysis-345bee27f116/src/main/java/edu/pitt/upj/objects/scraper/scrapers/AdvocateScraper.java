package edu.pitt.upj.objects.scraper.scrapers;

import edu.pitt.upj.objects.scraper.Scraper;
import edu.pitt.upj.objects.scraper.ScraperDTO;

import java.util.List;
import java.util.Objects;
import java.util.concurrent.ThreadLocalRandom;

public class AdvocateScraper extends Scraper {

    public AdvocateScraper()
    {
        super("https://upj-advocate.com/category/news/");
    }

    @Override
    public List<ScraperDTO> scrape() {
        var document = getDocument(); // blocking
        if (document == null) return List.of();

        var links = document.select("a[href]")
                .stream()
                .map(e -> e.attr("href"))
                .filter(e -> e.contains("/news/"))
                .toList();


        var linksSubList = links.subList(2, links.size() - 1)
                .stream()
                .skip(ThreadLocalRandom.current().nextInt(0, 5))
                .limit(3)
                .toList();

        return linksSubList.stream()
                .map(this::getDocument)
                .filter(Objects::nonNull)
                .map(e -> {
                    var content = e.getElementsByClass("storycontent").text();
                    return new ScraperDTO(e.baseUri(), content);
                }).toList();


    }


}
