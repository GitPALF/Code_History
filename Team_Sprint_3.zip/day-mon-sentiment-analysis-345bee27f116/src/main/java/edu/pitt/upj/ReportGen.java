package edu.pitt.upj;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;


public class ReportGen {
    // Lists must be instantiated as ArrayLists because Lists are abstract and cannot be instantiated as List Objects
    // Not instantiating the Lists results in a NullPointerException
    private final  List<String> siteNames = new ArrayList<>();
    private final List<String> siteLinks = new ArrayList<>();
    private final  List<String> siteSentiments = new ArrayList<>();
    private final List<Float> confidence = new ArrayList<>();
    private final List<String> keywords = new ArrayList<>();


    public List<String> getSiteNames() {
        return siteNames;
    }

    public List<String> getSiteLinks() {
        return siteLinks;
    }

    public List<String> getSiteSentiments() {
        return siteSentiments;
    }

    public List<Float> getConfidence() {
        return confidence;
    }

    public List<String> getKeywords() {
        return keywords;
    }

    public void generateReport(){

        // Create PDF document instance
        Document doc = new Document();
        LocalDate reportDate = LocalDate.now();





        try{
            // Generate a PDF in a specified location
            PdfWriter writer = PdfWriter.getInstance(doc, new FileOutputStream("PDFs\\"+ reportDate + ".pdf"));



            // Open PDF for editing
            doc.open();

            // Create header
            Font headerFont = new Font(Font.FontFamily.TIMES_ROMAN, 20.0f);
            Font linkFont = new Font(Font.FontFamily.TIMES_ROMAN,14.0f,3, BaseColor.BLUE);
            Paragraph title = new Paragraph("Sentiment report " + reportDate, headerFont);
            doc.add(title);
            // Add a paragraph
            for(int i = 0; i< siteNames.size(); i++){

                Chunk site = new Chunk(siteNames.get(i) + "\n");
                Chunk link = new Chunk(siteLinks.get(i));
                site.setFont(headerFont);
                link.setFont(linkFont);

                Paragraph report = new Paragraph("Overall sentiment:  " + siteSentiments.get(i) + "\nConfidence: " + confidence.get(i));
                Chunk keys = new Chunk("Keywords: "+ keywords.get(i) + "\n\n\n\n");
                doc.add(site);
                doc.add(link);
                doc.add(report);
                doc.add(keys);


            }


            // Close the PDF after editing
            doc.close();

            // Close the writer
            writer.close();
        }
        catch(DocumentException e){
            System.out.println("Document writing failed");
        }
        catch (FileNotFoundException e){
            e.printStackTrace();
        }

    }



}