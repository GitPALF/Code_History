package edu.pitt.upj.objects.scraper;

/**
 *
 * @param url the url of the website that the scrapper is scraping
 * @param data the data that the scrapper is scraping from the website
 */
public record ScraperDTO(String url, String data)
{
    private static final int AWS_CHARACTER_BYTE_LIMIT = 5000;

    @Override
    public String data() { return data.length() < AWS_CHARACTER_BYTE_LIMIT ? data : data.substring(0, AWS_CHARACTER_BYTE_LIMIT - 200); }
}
