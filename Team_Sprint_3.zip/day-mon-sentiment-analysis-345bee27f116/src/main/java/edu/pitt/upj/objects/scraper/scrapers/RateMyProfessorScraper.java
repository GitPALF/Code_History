package edu.pitt.upj.objects.scraper.scrapers;

import edu.pitt.upj.objects.scraper.Scraper;
import edu.pitt.upj.objects.scraper.ScraperDTO;

import java.util.List;

public class RateMyProfessorScraper extends Scraper
{

    public RateMyProfessorScraper() {
        super("https://www.ratemyprofessors.com/campusRatings.jsp?sid=1515");
    }

    @Override
    public List<ScraperDTO> scrape()
    {
        var document = getDocument();
        if (document == null)
        {
            return List.of();
        }

        return document.getElementsByTag("p").subList(0, 3)
                .stream()
                .map(e -> {
                    var content = e.text();
                    return new ScraperDTO(this.getScrapeUrl(), content);
                }).toList();
    }




}
