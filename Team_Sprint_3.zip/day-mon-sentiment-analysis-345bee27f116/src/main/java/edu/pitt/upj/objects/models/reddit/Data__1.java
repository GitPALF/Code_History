
package edu.pitt.upj.objects.models.reddit;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;

public class Data__1 {

    private Object approved_at_utc;
    private String subreddit;
    private String selftext;
    private String author_fullname;
    private Boolean saved;
    private Object mod_reason_title;
    private Integer gilded;
    private Boolean clicked;
    private String title;
    private List<Object> link_flair_richtext = null;
    private String subreddit_name_prefixed;
    private Boolean hidden;
    private Object pwls;
    private Object link_flair_css_class;
    private Integer downs;
    private Object thumbnail_height;
    private Object top_awarded_type;
    private Boolean hide_score;
    private String name;
    private Boolean quarantine;
    private String link_flair_text_color;
    private Double upvote_ratio;
    private Object author_flair_background_color;
    private String subreddit_type;
    private Integer ups;
    private Integer total_awards_received;
    private Media_embed media_embed;
    private Object thumbnail_width;
    private Object author_flair_template_id;
    private Boolean is_original_content;
    private List<Object> user_reports = null;
    private Object secure_media;
    private Boolean is_reddit_media_domain;
    private Boolean is_meta;
    private Object category;
    private Secure_media_embed secure_media_embed;
    private Object link_flair_text;
    private Boolean can_mod_post;
    private Integer score;
    private Object approved_by;
    private Boolean is_created_from_ads_ui;
    private Boolean author_premium;
    private String thumbnail;
    private Boolean edited;
    private Object author_flair_css_class;
    private List<Object> author_flair_richtext = null;
    private Gildings gildings;
    private Object content_categories;
    private Boolean is_self;
    private Object mod_note;
    private Double created;
    private String link_flair_type;
    private Object wls;
    private Object removed_by_category;
    private Object banned_by;
    private String author_flair_type;
    private String domain;
    private Boolean allow_live_comments;
    private String selftext_html;
    private Object likes;
    private Object suggested_sort;
    private Object banned_at_utc;
    private Object view_count;
    private Boolean archived;
    private Boolean no_follow;
    private Boolean is_crosspostable;
    private Boolean pinned;
    private Boolean over_18;
    private List<Object> all_awardings = null;
    private List<Object> awarders = null;
    private Boolean media_only;
    private Boolean can_gild;
    private Boolean spoiler;
    private Boolean locked;
    private Object author_flair_text;
    private List<Object> treatment_tags = null;
    private Boolean visited;
    private Object removed_by;
    private Object num_reports;
    private Object distinguished;
    private String subreddit_id;
    private Boolean author_is_blocked;
    private Object mod_reason_by;
    private Object removal_reason;
    private String link_flair_background_color;
    private String id;
    private Boolean is_robot_indexable;
    private Object report_reasons;
    private String author;
    private Object discussion_type;
    private Integer num_comments;
    private Boolean send_replies;
    private Object whitelist_status;
    private Boolean contest_mode;
    private List<Object> mod_reports = null;
    private Boolean author_patreon_flair;
    private Object author_flair_text_color;
    private String permalink;
    private Object parent_whitelist_status;
    private Boolean stickied;
    private String url;
    private Integer subreddit_subscribers;
    private Double created_utc;
    private Integer num_crossposts;
    private Object media;
    private Boolean is_video;
    private String post_hint;
    private String url_overridden_by_dest;
    private Preview preview;
    private Poll_data poll_data;
    private String link_flair_template_id;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public Object getApproved_at_utc() {
        return approved_at_utc;
    }

    public void setApproved_at_utc(Object approved_at_utc) {
        this.approved_at_utc = approved_at_utc;
    }

    public Data__1 withApproved_at_utc(Object approved_at_utc) {
        this.approved_at_utc = approved_at_utc;
        return this;
    }

    public String getSubreddit() {
        return subreddit;
    }

    public void setSubreddit(String subreddit) {
        this.subreddit = subreddit;
    }

    public Data__1 withSubreddit(String subreddit) {
        this.subreddit = subreddit;
        return this;
    }

    public String getSelftext() {
        return selftext;
    }

    public void setSelftext(String selftext) {
        this.selftext = selftext;
    }

    public Data__1 withSelftext(String selftext) {
        this.selftext = selftext;
        return this;
    }

    public String getAuthor_fullname() {
        return author_fullname;
    }

    public void setAuthor_fullname(String author_fullname) {
        this.author_fullname = author_fullname;
    }

    public Data__1 withAuthor_fullname(String author_fullname) {
        this.author_fullname = author_fullname;
        return this;
    }

    public Boolean getSaved() {
        return saved;
    }

    public void setSaved(Boolean saved) {
        this.saved = saved;
    }

    public Data__1 withSaved(Boolean saved) {
        this.saved = saved;
        return this;
    }

    public Object getMod_reason_title() {
        return mod_reason_title;
    }

    public void setMod_reason_title(Object mod_reason_title) {
        this.mod_reason_title = mod_reason_title;
    }

    public Data__1 withMod_reason_title(Object mod_reason_title) {
        this.mod_reason_title = mod_reason_title;
        return this;
    }

    public Integer getGilded() {
        return gilded;
    }

    public void setGilded(Integer gilded) {
        this.gilded = gilded;
    }

    public Data__1 withGilded(Integer gilded) {
        this.gilded = gilded;
        return this;
    }

    public Boolean getClicked() {
        return clicked;
    }

    public void setClicked(Boolean clicked) {
        this.clicked = clicked;
    }

    public Data__1 withClicked(Boolean clicked) {
        this.clicked = clicked;
        return this;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Data__1 withTitle(String title) {
        this.title = title;
        return this;
    }

    public List<Object> getLink_flair_richtext() {
        return link_flair_richtext;
    }

    public void setLink_flair_richtext(List<Object> link_flair_richtext) {
        this.link_flair_richtext = link_flair_richtext;
    }

    public Data__1 withLink_flair_richtext(List<Object> link_flair_richtext) {
        this.link_flair_richtext = link_flair_richtext;
        return this;
    }

    public String getSubreddit_name_prefixed() {
        return subreddit_name_prefixed;
    }

    public void setSubreddit_name_prefixed(String subreddit_name_prefixed) {
        this.subreddit_name_prefixed = subreddit_name_prefixed;
    }

    public Data__1 withSubreddit_name_prefixed(String subreddit_name_prefixed) {
        this.subreddit_name_prefixed = subreddit_name_prefixed;
        return this;
    }

    public Boolean getHidden() {
        return hidden;
    }

    public void setHidden(Boolean hidden) {
        this.hidden = hidden;
    }

    public Data__1 withHidden(Boolean hidden) {
        this.hidden = hidden;
        return this;
    }

    public Object getPwls() {
        return pwls;
    }

    public void setPwls(Object pwls) {
        this.pwls = pwls;
    }

    public Data__1 withPwls(Object pwls) {
        this.pwls = pwls;
        return this;
    }

    public Object getLink_flair_css_class() {
        return link_flair_css_class;
    }

    public void setLink_flair_css_class(Object link_flair_css_class) {
        this.link_flair_css_class = link_flair_css_class;
    }

    public Data__1 withLink_flair_css_class(Object link_flair_css_class) {
        this.link_flair_css_class = link_flair_css_class;
        return this;
    }

    public Integer getDowns() {
        return downs;
    }

    public void setDowns(Integer downs) {
        this.downs = downs;
    }

    public Data__1 withDowns(Integer downs) {
        this.downs = downs;
        return this;
    }

    public Object getThumbnail_height() {
        return thumbnail_height;
    }

    public void setThumbnail_height(Object thumbnail_height) {
        this.thumbnail_height = thumbnail_height;
    }

    public Data__1 withThumbnail_height(Object thumbnail_height) {
        this.thumbnail_height = thumbnail_height;
        return this;
    }

    public Object getTop_awarded_type() {
        return top_awarded_type;
    }

    public void setTop_awarded_type(Object top_awarded_type) {
        this.top_awarded_type = top_awarded_type;
    }

    public Data__1 withTop_awarded_type(Object top_awarded_type) {
        this.top_awarded_type = top_awarded_type;
        return this;
    }

    public Boolean getHide_score() {
        return hide_score;
    }

    public void setHide_score(Boolean hide_score) {
        this.hide_score = hide_score;
    }

    public Data__1 withHide_score(Boolean hide_score) {
        this.hide_score = hide_score;
        return this;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Data__1 withName(String name) {
        this.name = name;
        return this;
    }

    public Boolean getQuarantine() {
        return quarantine;
    }

    public void setQuarantine(Boolean quarantine) {
        this.quarantine = quarantine;
    }

    public Data__1 withQuarantine(Boolean quarantine) {
        this.quarantine = quarantine;
        return this;
    }

    public String getLink_flair_text_color() {
        return link_flair_text_color;
    }

    public void setLink_flair_text_color(String link_flair_text_color) {
        this.link_flair_text_color = link_flair_text_color;
    }

    public Data__1 withLink_flair_text_color(String link_flair_text_color) {
        this.link_flair_text_color = link_flair_text_color;
        return this;
    }

    public Double getUpvote_ratio() {
        return upvote_ratio;
    }

    public void setUpvote_ratio(Double upvote_ratio) {
        this.upvote_ratio = upvote_ratio;
    }

    public Data__1 withUpvote_ratio(Double upvote_ratio) {
        this.upvote_ratio = upvote_ratio;
        return this;
    }

    public Object getAuthor_flair_background_color() {
        return author_flair_background_color;
    }

    public void setAuthor_flair_background_color(Object author_flair_background_color) {
        this.author_flair_background_color = author_flair_background_color;
    }

    public Data__1 withAuthor_flair_background_color(Object author_flair_background_color) {
        this.author_flair_background_color = author_flair_background_color;
        return this;
    }

    public String getSubreddit_type() {
        return subreddit_type;
    }

    public void setSubreddit_type(String subreddit_type) {
        this.subreddit_type = subreddit_type;
    }

    public Data__1 withSubreddit_type(String subreddit_type) {
        this.subreddit_type = subreddit_type;
        return this;
    }

    public Integer getUps() {
        return ups;
    }

    public void setUps(Integer ups) {
        this.ups = ups;
    }

    public Data__1 withUps(Integer ups) {
        this.ups = ups;
        return this;
    }

    public Integer getTotal_awards_received() {
        return total_awards_received;
    }

    public void setTotal_awards_received(Integer total_awards_received) {
        this.total_awards_received = total_awards_received;
    }

    public Data__1 withTotal_awards_received(Integer total_awards_received) {
        this.total_awards_received = total_awards_received;
        return this;
    }

    public Media_embed getMedia_embed() {
        return media_embed;
    }

    public void setMedia_embed(Media_embed media_embed) {
        this.media_embed = media_embed;
    }

    public Data__1 withMedia_embed(Media_embed media_embed) {
        this.media_embed = media_embed;
        return this;
    }

    public Object getThumbnail_width() {
        return thumbnail_width;
    }

    public void setThumbnail_width(Object thumbnail_width) {
        this.thumbnail_width = thumbnail_width;
    }

    public Data__1 withThumbnail_width(Object thumbnail_width) {
        this.thumbnail_width = thumbnail_width;
        return this;
    }

    public Object getAuthor_flair_template_id() {
        return author_flair_template_id;
    }

    public void setAuthor_flair_template_id(Object author_flair_template_id) {
        this.author_flair_template_id = author_flair_template_id;
    }

    public Data__1 withAuthor_flair_template_id(Object author_flair_template_id) {
        this.author_flair_template_id = author_flair_template_id;
        return this;
    }

    public Boolean getIs_original_content() {
        return is_original_content;
    }

    public void setIs_original_content(Boolean is_original_content) {
        this.is_original_content = is_original_content;
    }

    public Data__1 withIs_original_content(Boolean is_original_content) {
        this.is_original_content = is_original_content;
        return this;
    }

    public List<Object> getUser_reports() {
        return user_reports;
    }

    public void setUser_reports(List<Object> user_reports) {
        this.user_reports = user_reports;
    }

    public Data__1 withUser_reports(List<Object> user_reports) {
        this.user_reports = user_reports;
        return this;
    }

    public Object getSecure_media() {
        return secure_media;
    }

    public void setSecure_media(Object secure_media) {
        this.secure_media = secure_media;
    }

    public Data__1 withSecure_media(Object secure_media) {
        this.secure_media = secure_media;
        return this;
    }

    public Boolean getIs_reddit_media_domain() {
        return is_reddit_media_domain;
    }

    public void setIs_reddit_media_domain(Boolean is_reddit_media_domain) {
        this.is_reddit_media_domain = is_reddit_media_domain;
    }

    public Data__1 withIs_reddit_media_domain(Boolean is_reddit_media_domain) {
        this.is_reddit_media_domain = is_reddit_media_domain;
        return this;
    }

    public Boolean getIs_meta() {
        return is_meta;
    }

    public void setIs_meta(Boolean is_meta) {
        this.is_meta = is_meta;
    }

    public Data__1 withIs_meta(Boolean is_meta) {
        this.is_meta = is_meta;
        return this;
    }

    public Object getCategory() {
        return category;
    }

    public void setCategory(Object category) {
        this.category = category;
    }

    public Data__1 withCategory(Object category) {
        this.category = category;
        return this;
    }

    public Secure_media_embed getSecure_media_embed() {
        return secure_media_embed;
    }

    public void setSecure_media_embed(Secure_media_embed secure_media_embed) {
        this.secure_media_embed = secure_media_embed;
    }

    public Data__1 withSecure_media_embed(Secure_media_embed secure_media_embed) {
        this.secure_media_embed = secure_media_embed;
        return this;
    }

    public Object getLink_flair_text() {
        return link_flair_text;
    }

    public void setLink_flair_text(Object link_flair_text) {
        this.link_flair_text = link_flair_text;
    }

    public Data__1 withLink_flair_text(Object link_flair_text) {
        this.link_flair_text = link_flair_text;
        return this;
    }

    public Boolean getCan_mod_post() {
        return can_mod_post;
    }

    public void setCan_mod_post(Boolean can_mod_post) {
        this.can_mod_post = can_mod_post;
    }

    public Data__1 withCan_mod_post(Boolean can_mod_post) {
        this.can_mod_post = can_mod_post;
        return this;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }

    public Data__1 withScore(Integer score) {
        this.score = score;
        return this;
    }

    public Object getApproved_by() {
        return approved_by;
    }

    public void setApproved_by(Object approved_by) {
        this.approved_by = approved_by;
    }

    public Data__1 withApproved_by(Object approved_by) {
        this.approved_by = approved_by;
        return this;
    }

    public Boolean getIs_created_from_ads_ui() {
        return is_created_from_ads_ui;
    }

    public void setIs_created_from_ads_ui(Boolean is_created_from_ads_ui) {
        this.is_created_from_ads_ui = is_created_from_ads_ui;
    }

    public Data__1 withIs_created_from_ads_ui(Boolean is_created_from_ads_ui) {
        this.is_created_from_ads_ui = is_created_from_ads_ui;
        return this;
    }

    public Boolean getAuthor_premium() {
        return author_premium;
    }

    public void setAuthor_premium(Boolean author_premium) {
        this.author_premium = author_premium;
    }

    public Data__1 withAuthor_premium(Boolean author_premium) {
        this.author_premium = author_premium;
        return this;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public Data__1 withThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
        return this;
    }

    public Boolean getEdited() {
        return edited;
    }

    public void setEdited(Boolean edited) {
        this.edited = edited;
    }

    public Data__1 withEdited(Boolean edited) {
        this.edited = edited;
        return this;
    }

    public Object getAuthor_flair_css_class() {
        return author_flair_css_class;
    }

    public void setAuthor_flair_css_class(Object author_flair_css_class) {
        this.author_flair_css_class = author_flair_css_class;
    }

    public Data__1 withAuthor_flair_css_class(Object author_flair_css_class) {
        this.author_flair_css_class = author_flair_css_class;
        return this;
    }

    public List<Object> getAuthor_flair_richtext() {
        return author_flair_richtext;
    }

    public void setAuthor_flair_richtext(List<Object> author_flair_richtext) {
        this.author_flair_richtext = author_flair_richtext;
    }

    public Data__1 withAuthor_flair_richtext(List<Object> author_flair_richtext) {
        this.author_flair_richtext = author_flair_richtext;
        return this;
    }

    public Gildings getGildings() {
        return gildings;
    }

    public void setGildings(Gildings gildings) {
        this.gildings = gildings;
    }

    public Data__1 withGildings(Gildings gildings) {
        this.gildings = gildings;
        return this;
    }

    public Object getContent_categories() {
        return content_categories;
    }

    public void setContent_categories(Object content_categories) {
        this.content_categories = content_categories;
    }

    public Data__1 withContent_categories(Object content_categories) {
        this.content_categories = content_categories;
        return this;
    }

    public Boolean getIs_self() {
        return is_self;
    }

    public void setIs_self(Boolean is_self) {
        this.is_self = is_self;
    }

    public Data__1 withIs_self(Boolean is_self) {
        this.is_self = is_self;
        return this;
    }

    public Object getMod_note() {
        return mod_note;
    }

    public void setMod_note(Object mod_note) {
        this.mod_note = mod_note;
    }

    public Data__1 withMod_note(Object mod_note) {
        this.mod_note = mod_note;
        return this;
    }

    public Double getCreated() {
        return created;
    }

    public void setCreated(Double created) {
        this.created = created;
    }

    public Data__1 withCreated(Double created) {
        this.created = created;
        return this;
    }

    public String getLink_flair_type() {
        return link_flair_type;
    }

    public void setLink_flair_type(String link_flair_type) {
        this.link_flair_type = link_flair_type;
    }

    public Data__1 withLink_flair_type(String link_flair_type) {
        this.link_flair_type = link_flair_type;
        return this;
    }

    public Object getWls() {
        return wls;
    }

    public void setWls(Object wls) {
        this.wls = wls;
    }

    public Data__1 withWls(Object wls) {
        this.wls = wls;
        return this;
    }

    public Object getRemoved_by_category() {
        return removed_by_category;
    }

    public void setRemoved_by_category(Object removed_by_category) {
        this.removed_by_category = removed_by_category;
    }

    public Data__1 withRemoved_by_category(Object removed_by_category) {
        this.removed_by_category = removed_by_category;
        return this;
    }

    public Object getBanned_by() {
        return banned_by;
    }

    public void setBanned_by(Object banned_by) {
        this.banned_by = banned_by;
    }

    public Data__1 withBanned_by(Object banned_by) {
        this.banned_by = banned_by;
        return this;
    }

    public String getAuthor_flair_type() {
        return author_flair_type;
    }

    public void setAuthor_flair_type(String author_flair_type) {
        this.author_flair_type = author_flair_type;
    }

    public Data__1 withAuthor_flair_type(String author_flair_type) {
        this.author_flair_type = author_flair_type;
        return this;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public Data__1 withDomain(String domain) {
        this.domain = domain;
        return this;
    }

    public Boolean getAllow_live_comments() {
        return allow_live_comments;
    }

    public void setAllow_live_comments(Boolean allow_live_comments) {
        this.allow_live_comments = allow_live_comments;
    }

    public Data__1 withAllow_live_comments(Boolean allow_live_comments) {
        this.allow_live_comments = allow_live_comments;
        return this;
    }

    public String getSelftext_html() {
        return selftext_html;
    }

    public void setSelftext_html(String selftext_html) {
        this.selftext_html = selftext_html;
    }

    public Data__1 withSelftext_html(String selftext_html) {
        this.selftext_html = selftext_html;
        return this;
    }

    public Object getLikes() {
        return likes;
    }

    public void setLikes(Object likes) {
        this.likes = likes;
    }

    public Data__1 withLikes(Object likes) {
        this.likes = likes;
        return this;
    }

    public Object getSuggested_sort() {
        return suggested_sort;
    }

    public void setSuggested_sort(Object suggested_sort) {
        this.suggested_sort = suggested_sort;
    }

    public Data__1 withSuggested_sort(Object suggested_sort) {
        this.suggested_sort = suggested_sort;
        return this;
    }

    public Object getBanned_at_utc() {
        return banned_at_utc;
    }

    public void setBanned_at_utc(Object banned_at_utc) {
        this.banned_at_utc = banned_at_utc;
    }

    public Data__1 withBanned_at_utc(Object banned_at_utc) {
        this.banned_at_utc = banned_at_utc;
        return this;
    }

    public Object getView_count() {
        return view_count;
    }

    public void setView_count(Object view_count) {
        this.view_count = view_count;
    }

    public Data__1 withView_count(Object view_count) {
        this.view_count = view_count;
        return this;
    }

    public Boolean getArchived() {
        return archived;
    }

    public void setArchived(Boolean archived) {
        this.archived = archived;
    }

    public Data__1 withArchived(Boolean archived) {
        this.archived = archived;
        return this;
    }

    public Boolean getNo_follow() {
        return no_follow;
    }

    public void setNo_follow(Boolean no_follow) {
        this.no_follow = no_follow;
    }

    public Data__1 withNo_follow(Boolean no_follow) {
        this.no_follow = no_follow;
        return this;
    }

    public Boolean getIs_crosspostable() {
        return is_crosspostable;
    }

    public void setIs_crosspostable(Boolean is_crosspostable) {
        this.is_crosspostable = is_crosspostable;
    }

    public Data__1 withIs_crosspostable(Boolean is_crosspostable) {
        this.is_crosspostable = is_crosspostable;
        return this;
    }

    public Boolean getPinned() {
        return pinned;
    }

    public void setPinned(Boolean pinned) {
        this.pinned = pinned;
    }

    public Data__1 withPinned(Boolean pinned) {
        this.pinned = pinned;
        return this;
    }

    public Boolean getOver_18() {
        return over_18;
    }

    public void setOver_18(Boolean over_18) {
        this.over_18 = over_18;
    }

    public Data__1 withOver_18(Boolean over_18) {
        this.over_18 = over_18;
        return this;
    }

    public List<Object> getAll_awardings() {
        return all_awardings;
    }

    public void setAll_awardings(List<Object> all_awardings) {
        this.all_awardings = all_awardings;
    }

    public Data__1 withAll_awardings(List<Object> all_awardings) {
        this.all_awardings = all_awardings;
        return this;
    }

    public List<Object> getAwarders() {
        return awarders;
    }

    public void setAwarders(List<Object> awarders) {
        this.awarders = awarders;
    }

    public Data__1 withAwarders(List<Object> awarders) {
        this.awarders = awarders;
        return this;
    }

    public Boolean getMedia_only() {
        return media_only;
    }

    public void setMedia_only(Boolean media_only) {
        this.media_only = media_only;
    }

    public Data__1 withMedia_only(Boolean media_only) {
        this.media_only = media_only;
        return this;
    }

    public Boolean getCan_gild() {
        return can_gild;
    }

    public void setCan_gild(Boolean can_gild) {
        this.can_gild = can_gild;
    }

    public Data__1 withCan_gild(Boolean can_gild) {
        this.can_gild = can_gild;
        return this;
    }

    public Boolean getSpoiler() {
        return spoiler;
    }

    public void setSpoiler(Boolean spoiler) {
        this.spoiler = spoiler;
    }

    public Data__1 withSpoiler(Boolean spoiler) {
        this.spoiler = spoiler;
        return this;
    }

    public Boolean getLocked() {
        return locked;
    }

    public void setLocked(Boolean locked) {
        this.locked = locked;
    }

    public Data__1 withLocked(Boolean locked) {
        this.locked = locked;
        return this;
    }

    public Object getAuthor_flair_text() {
        return author_flair_text;
    }

    public void setAuthor_flair_text(Object author_flair_text) {
        this.author_flair_text = author_flair_text;
    }

    public Data__1 withAuthor_flair_text(Object author_flair_text) {
        this.author_flair_text = author_flair_text;
        return this;
    }

    public List<Object> getTreatment_tags() {
        return treatment_tags;
    }

    public void setTreatment_tags(List<Object> treatment_tags) {
        this.treatment_tags = treatment_tags;
    }

    public Data__1 withTreatment_tags(List<Object> treatment_tags) {
        this.treatment_tags = treatment_tags;
        return this;
    }

    public Boolean getVisited() {
        return visited;
    }

    public void setVisited(Boolean visited) {
        this.visited = visited;
    }

    public Data__1 withVisited(Boolean visited) {
        this.visited = visited;
        return this;
    }

    public Object getRemoved_by() {
        return removed_by;
    }

    public void setRemoved_by(Object removed_by) {
        this.removed_by = removed_by;
    }

    public Data__1 withRemoved_by(Object removed_by) {
        this.removed_by = removed_by;
        return this;
    }

    public Object getNum_reports() {
        return num_reports;
    }

    public void setNum_reports(Object num_reports) {
        this.num_reports = num_reports;
    }

    public Data__1 withNum_reports(Object num_reports) {
        this.num_reports = num_reports;
        return this;
    }

    public Object getDistinguished() {
        return distinguished;
    }

    public void setDistinguished(Object distinguished) {
        this.distinguished = distinguished;
    }

    public Data__1 withDistinguished(Object distinguished) {
        this.distinguished = distinguished;
        return this;
    }

    public String getSubreddit_id() {
        return subreddit_id;
    }

    public void setSubreddit_id(String subreddit_id) {
        this.subreddit_id = subreddit_id;
    }

    public Data__1 withSubreddit_id(String subreddit_id) {
        this.subreddit_id = subreddit_id;
        return this;
    }

    public Boolean getAuthor_is_blocked() {
        return author_is_blocked;
    }

    public void setAuthor_is_blocked(Boolean author_is_blocked) {
        this.author_is_blocked = author_is_blocked;
    }

    public Data__1 withAuthor_is_blocked(Boolean author_is_blocked) {
        this.author_is_blocked = author_is_blocked;
        return this;
    }

    public Object getMod_reason_by() {
        return mod_reason_by;
    }

    public void setMod_reason_by(Object mod_reason_by) {
        this.mod_reason_by = mod_reason_by;
    }

    public Data__1 withMod_reason_by(Object mod_reason_by) {
        this.mod_reason_by = mod_reason_by;
        return this;
    }

    public Object getRemoval_reason() {
        return removal_reason;
    }

    public void setRemoval_reason(Object removal_reason) {
        this.removal_reason = removal_reason;
    }

    public Data__1 withRemoval_reason(Object removal_reason) {
        this.removal_reason = removal_reason;
        return this;
    }

    public String getLink_flair_background_color() {
        return link_flair_background_color;
    }

    public void setLink_flair_background_color(String link_flair_background_color) {
        this.link_flair_background_color = link_flair_background_color;
    }

    public Data__1 withLink_flair_background_color(String link_flair_background_color) {
        this.link_flair_background_color = link_flair_background_color;
        return this;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Data__1 withId(String id) {
        this.id = id;
        return this;
    }

    public Boolean getIs_robot_indexable() {
        return is_robot_indexable;
    }

    public void setIs_robot_indexable(Boolean is_robot_indexable) {
        this.is_robot_indexable = is_robot_indexable;
    }

    public Data__1 withIs_robot_indexable(Boolean is_robot_indexable) {
        this.is_robot_indexable = is_robot_indexable;
        return this;
    }

    public Object getReport_reasons() {
        return report_reasons;
    }

    public void setReport_reasons(Object report_reasons) {
        this.report_reasons = report_reasons;
    }

    public Data__1 withReport_reasons(Object report_reasons) {
        this.report_reasons = report_reasons;
        return this;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public Data__1 withAuthor(String author) {
        this.author = author;
        return this;
    }

    public Object getDiscussion_type() {
        return discussion_type;
    }

    public void setDiscussion_type(Object discussion_type) {
        this.discussion_type = discussion_type;
    }

    public Data__1 withDiscussion_type(Object discussion_type) {
        this.discussion_type = discussion_type;
        return this;
    }

    public Integer getNum_comments() {
        return num_comments;
    }

    public void setNum_comments(Integer num_comments) {
        this.num_comments = num_comments;
    }

    public Data__1 withNum_comments(Integer num_comments) {
        this.num_comments = num_comments;
        return this;
    }

    public Boolean getSend_replies() {
        return send_replies;
    }

    public void setSend_replies(Boolean send_replies) {
        this.send_replies = send_replies;
    }

    public Data__1 withSend_replies(Boolean send_replies) {
        this.send_replies = send_replies;
        return this;
    }

    public Object getWhitelist_status() {
        return whitelist_status;
    }

    public void setWhitelist_status(Object whitelist_status) {
        this.whitelist_status = whitelist_status;
    }

    public Data__1 withWhitelist_status(Object whitelist_status) {
        this.whitelist_status = whitelist_status;
        return this;
    }

    public Boolean getContest_mode() {
        return contest_mode;
    }

    public void setContest_mode(Boolean contest_mode) {
        this.contest_mode = contest_mode;
    }

    public Data__1 withContest_mode(Boolean contest_mode) {
        this.contest_mode = contest_mode;
        return this;
    }

    public List<Object> getMod_reports() {
        return mod_reports;
    }

    public void setMod_reports(List<Object> mod_reports) {
        this.mod_reports = mod_reports;
    }

    public Data__1 withMod_reports(List<Object> mod_reports) {
        this.mod_reports = mod_reports;
        return this;
    }

    public Boolean getAuthor_patreon_flair() {
        return author_patreon_flair;
    }

    public void setAuthor_patreon_flair(Boolean author_patreon_flair) {
        this.author_patreon_flair = author_patreon_flair;
    }

    public Data__1 withAuthor_patreon_flair(Boolean author_patreon_flair) {
        this.author_patreon_flair = author_patreon_flair;
        return this;
    }

    public Object getAuthor_flair_text_color() {
        return author_flair_text_color;
    }

    public void setAuthor_flair_text_color(Object author_flair_text_color) {
        this.author_flair_text_color = author_flair_text_color;
    }

    public Data__1 withAuthor_flair_text_color(Object author_flair_text_color) {
        this.author_flair_text_color = author_flair_text_color;
        return this;
    }

    public String getPermalink() {
        return permalink;
    }

    public void setPermalink(String permalink) {
        this.permalink = permalink;
    }

    public Data__1 withPermalink(String permalink) {
        this.permalink = permalink;
        return this;
    }

    public Object getParent_whitelist_status() {
        return parent_whitelist_status;
    }

    public void setParent_whitelist_status(Object parent_whitelist_status) {
        this.parent_whitelist_status = parent_whitelist_status;
    }

    public Data__1 withParent_whitelist_status(Object parent_whitelist_status) {
        this.parent_whitelist_status = parent_whitelist_status;
        return this;
    }

    public Boolean getStickied() {
        return stickied;
    }

    public void setStickied(Boolean stickied) {
        this.stickied = stickied;
    }

    public Data__1 withStickied(Boolean stickied) {
        this.stickied = stickied;
        return this;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Data__1 withUrl(String url) {
        this.url = url;
        return this;
    }

    public Integer getSubreddit_subscribers() {
        return subreddit_subscribers;
    }

    public void setSubreddit_subscribers(Integer subreddit_subscribers) {
        this.subreddit_subscribers = subreddit_subscribers;
    }

    public Data__1 withSubreddit_subscribers(Integer subreddit_subscribers) {
        this.subreddit_subscribers = subreddit_subscribers;
        return this;
    }

    public Double getCreated_utc() {
        return created_utc;
    }

    public void setCreated_utc(Double created_utc) {
        this.created_utc = created_utc;
    }

    public Data__1 withCreated_utc(Double created_utc) {
        this.created_utc = created_utc;
        return this;
    }

    public Integer getNum_crossposts() {
        return num_crossposts;
    }

    public void setNum_crossposts(Integer num_crossposts) {
        this.num_crossposts = num_crossposts;
    }

    public Data__1 withNum_crossposts(Integer num_crossposts) {
        this.num_crossposts = num_crossposts;
        return this;
    }

    public Object getMedia() {
        return media;
    }

    public void setMedia(Object media) {
        this.media = media;
    }

    public Data__1 withMedia(Object media) {
        this.media = media;
        return this;
    }

    public Boolean getIs_video() {
        return is_video;
    }

    public void setIs_video(Boolean is_video) {
        this.is_video = is_video;
    }

    public Data__1 withIs_video(Boolean is_video) {
        this.is_video = is_video;
        return this;
    }

    public String getPost_hint() {
        return post_hint;
    }

    public void setPost_hint(String post_hint) {
        this.post_hint = post_hint;
    }

    public Data__1 withPost_hint(String post_hint) {
        this.post_hint = post_hint;
        return this;
    }

    public String getUrl_overridden_by_dest() {
        return url_overridden_by_dest;
    }

    public void setUrl_overridden_by_dest(String url_overridden_by_dest) {
        this.url_overridden_by_dest = url_overridden_by_dest;
    }

    public Data__1 withUrl_overridden_by_dest(String url_overridden_by_dest) {
        this.url_overridden_by_dest = url_overridden_by_dest;
        return this;
    }

    public Preview getPreview() {
        return preview;
    }

    public void setPreview(Preview preview) {
        this.preview = preview;
    }

    public Data__1 withPreview(Preview preview) {
        this.preview = preview;
        return this;
    }

    public Poll_data getPoll_data() {
        return poll_data;
    }

    public void setPoll_data(Poll_data poll_data) {
        this.poll_data = poll_data;
    }

    public Data__1 withPoll_data(Poll_data poll_data) {
        this.poll_data = poll_data;
        return this;
    }

    public String getLink_flair_template_id() {
        return link_flair_template_id;
    }

    public void setLink_flair_template_id(String link_flair_template_id) {
        this.link_flair_template_id = link_flair_template_id;
    }

    public Data__1 withLink_flair_template_id(String link_flair_template_id) {
        this.link_flair_template_id = link_flair_template_id;
        return this;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Data__1 withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

}
