package edu.pitt.upj.objects.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

public record NicheModel(long page, long limit, long total, List<Review> reviews) {


    @Nullable
    public static NicheModel asModel(String json) {

        var om = new ObjectMapper();
        try
        {
           return om.readValue(json, NicheModel.class);
        }
        catch (Exception e)
        {
            return null;
        }

    }
    public record Review(UUID guid, String body, long rating, @JsonIgnore Author author, @JsonIgnore OffsetDateTime created, @JsonIgnore Category[] categories) { }


    public enum Author {
        FRESHMAN("Freshman"), JUNIOR("Junior"), SENIOR("Senior"), SOPHOMORE("Sophomore");

        private final String name;

        Author(String name) {
            this.name = name;
        }

        public String getName() {
            return name;
        }
    }



    public enum Category {
        OVERALL_EXPERIENCE;

        public String toValue() {
            if (this == Category.OVERALL_EXPERIENCE) {
                return "Overall Experience";
            }
            return null;
        }

        public static Category forValue(String value) throws IOException {
            if (value.equals("Overall Experience")) return OVERALL_EXPERIENCE;
            throw new IOException("Cannot deserialize Category");
        }
    }
}

