package edu.pitt.upj.objects.sentiment;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.comprehend.AmazonComprehend;
import com.amazonaws.services.comprehend.AmazonComprehendClientBuilder;
import com.amazonaws.services.comprehend.model.*;
import edu.pitt.upj.handlers.ConfigHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.StandardCharsets;
import java.util.List;


public class Sentiment {

    private static volatile Sentiment instance = null;
    private static final ConfigHandler CONFIG_HANDLER = ConfigHandler.getInstance();
    private static final Regions REGION = Regions.US_WEST_2;
    private static final AWSStaticCredentialsProvider CREDENTIALS = new AWSStaticCredentialsProvider(new BasicAWSCredentials(CONFIG_HANDLER.getConfig().publicKey(), CONFIG_HANDLER.getConfig().privateKey()));
    private final AmazonComprehend client = AmazonComprehendClientBuilder.standard().withCredentials(CREDENTIALS).withRegion(REGION).build();

    private Sentiment() {
    }

    public static Sentiment getInstance() {
        if (instance == null) {
            synchronized (Sentiment.class) {
                if (instance == null) {
                    instance = new Sentiment();
                }
            }
        }
        return instance;
    }

    public DetectSentimentResult detectSentiments(String text)
    {
        return client.detectSentiment(
                new DetectSentimentRequest()
                        .withText(text)
                        .withLanguageCode(LanguageCode.En)

        );
    }

    public List<KeyPhrase> detectAllKeyPhrases(String text)
    {
       var phrases =  client.detectKeyPhrases(
                new DetectKeyPhrasesRequest()
                        .withText(text)
                        .withLanguageCode(LanguageCode.En)
        );

       return phrases.getKeyPhrases();
    }
}