
package edu.pitt.upj.objects.models.reddit;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class Mp4 {

    private Source__2 source;
    private List<Resolution__2> resolutions = null;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public Source__2 getSource() {
        return source;
    }

    public void setSource(Source__2 source) {
        this.source = source;
    }

    public Mp4 withSource(Source__2 source) {
        this.source = source;
        return this;
    }

    public List<Resolution__2> getResolutions() {
        return resolutions;
    }

    public void setResolutions(List<Resolution__2> resolutions) {
        this.resolutions = resolutions;
    }

    public Mp4 withResolutions(List<Resolution__2> resolutions) {
        this.resolutions = resolutions;
        return this;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Mp4 withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

}
