package edu.pitt.upj.objects.scraper.scrapers;

import edu.pitt.upj.objects.models.reddit.RedditModel;
import edu.pitt.upj.objects.scraper.Scraper;
import edu.pitt.upj.objects.scraper.ScraperDTO;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class RedditScraper extends Scraper
{
    public RedditScraper() {
        super("https://www.reddit.com/r/UPJ/");
        this.jsonUrl = "https://www.reddit.com/r/UPJ/.json";

    }

    @Override
    public List<ScraperDTO> scrape()
    {
        var body = getBody();
        var model = RedditModel.asModel(body);
        if (model == null)
        {
            scraperLogger.warn("Reddit model is null");
            return List.of();
        }

        return model.getData().getChildren().stream()
                .map(child -> child.getData().getTitle() + " - " + child.getData().getSelftext())
                .filter(text -> !text.contains("poll"))
                .map(text -> new ScraperDTO(this.getScrapeUrl(), text)).collect(Collectors.toCollection(ArrayList::new));

    }
}
