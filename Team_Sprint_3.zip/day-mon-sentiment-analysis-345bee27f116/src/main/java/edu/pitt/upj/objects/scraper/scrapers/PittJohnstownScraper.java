package edu.pitt.upj.objects.scraper.scrapers;

import edu.pitt.upj.objects.scraper.Scraper;
import edu.pitt.upj.objects.scraper.ScraperDTO;

import java.util.List;

public class PittJohnstownScraper extends Scraper {


    public PittJohnstownScraper()
    {
        super("https://upj.pitt.edu/about/mission-and-vision");
    }

    public List<ScraperDTO> scrape()
    {
        var document = getDocument();

        if (document == null)
        {
            return List.of();
        }
        var links = document.getElementById("node-383");

        if (links == null)
        {
            scraperLogger.error("No element found with id node-383");
            return List.of();
        }

       return List.of(new ScraperDTO(links.baseUri(), links.text()));

    }
}
