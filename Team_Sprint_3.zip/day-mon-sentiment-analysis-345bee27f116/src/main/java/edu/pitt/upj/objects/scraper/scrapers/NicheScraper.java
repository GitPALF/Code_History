package edu.pitt.upj.objects.scraper.scrapers;

import edu.pitt.upj.objects.models.NicheModel;
import edu.pitt.upj.objects.scraper.Scraper;
import edu.pitt.upj.objects.scraper.ScraperDTO;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class NicheScraper extends Scraper
{
    private static final int PAGE_NUMBER = ThreadLocalRandom.current().nextInt(0, 25);


    public NicheScraper()
    {
        super("https://www.niche.com/colleges/university-of-pittsburgh---johnstown/reviews/");
        this.jsonUrl = "https://www.niche.com/api/entity-reviews/?e=37b0b5c4-ff20-4d65-902b-a429dffc1053&page=%d&limit=50".formatted(PAGE_NUMBER);
    }

    @Override
    public List<ScraperDTO> scrape()
    {
        var map = new HashMap<Integer, Integer>();
        var random = ThreadLocalRandom.current();
        var body = getBody();
        var model = NicheModel.asModel(body);

        if (model == null) return List.of();

        var list = new ArrayList<ScraperDTO>();

        for (var i = 0; i < 3; i++)
        {
            // ensure that the random number is not already in the map to get unique post
            var randomInt = random.nextInt(0, model.reviews().size());
            while (map.containsKey(randomInt)) randomInt = random.nextInt(0, model.reviews().size());
            var review = model.reviews().get(randomInt).body();
            map.put(randomInt, i);
            list.add(new ScraperDTO(this.getScrapeUrl(), review));
        }
        return list;

    }
}
