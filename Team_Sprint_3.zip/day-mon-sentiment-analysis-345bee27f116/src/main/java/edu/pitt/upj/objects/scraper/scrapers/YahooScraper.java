package edu.pitt.upj.objects.scraper.scrapers;


import edu.pitt.upj.objects.scraper.Scraper;
import edu.pitt.upj.objects.scraper.ScraperDTO;
import org.jsoup.nodes.Element;

import java.util.List;
import java.util.stream.Collectors;

public final class YahooScraper extends Scraper
{

    public YahooScraper() {
        super("https://www.yahoo.com/news/upj-students-present-research-space-115000982.html");
    }

    @Override
    public List<ScraperDTO> scrape()
    {
        var document = getDocument();
        if (document == null) return List.of();
        var paragraphs = document.getElementsByTag("p").stream().map(Element::text).collect(Collectors.joining("\n"));
        return List.of(new ScraperDTO(this.getScrapeUrl(), paragraphs));





    }
}
