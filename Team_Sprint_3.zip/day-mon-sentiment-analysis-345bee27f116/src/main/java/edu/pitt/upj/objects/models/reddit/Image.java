
package edu.pitt.upj.objects.models.reddit;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class Image {

    private Source source;
    private List<Resolution> resolutions = null;
    private Variants variants;
    private String id;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public Source getSource() {
        return source;
    }

    public void setSource(Source source) {
        this.source = source;
    }

    public Image withSource(Source source) {
        this.source = source;
        return this;
    }

    public List<Resolution> getResolutions() {
        return resolutions;
    }

    public void setResolutions(List<Resolution> resolutions) {
        this.resolutions = resolutions;
    }

    public Image withResolutions(List<Resolution> resolutions) {
        this.resolutions = resolutions;
        return this;
    }

    public Variants getVariants() {
        return variants;
    }

    public void setVariants(Variants variants) {
        this.variants = variants;
    }

    public Image withVariants(Variants variants) {
        this.variants = variants;
        return this;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Image withId(String id) {
        this.id = id;
        return this;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Image withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

}
