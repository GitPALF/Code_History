package edu.pitt.upj;

import com.amazonaws.services.comprehend.model.SentimentScore;
import edu.pitt.upj.objects.scraper.scrapers.*;
import edu.pitt.upj.objects.sentiment.Sentiment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Main {
    private static final Logger logger = LoggerFactory.getLogger(Main.class);
    private static final ReportGen generator = new ReportGen();

    public static void main(String[] args) throws InterruptedException {
        var executors = Executors.newFixedThreadPool(8);
        var list = List.of(
                new AdvocateScraper(),
                new RateMyProfessorScraper(),
                new PittJohnstownScraper(),
                new NicheScraper(),
                new StudentsReviewScraper(),
                new RedditScraper(),
                new YahooScraper(),
                new WTAJScraper(),
                new TribuneScraper(),
                new PittScraper()
        );

        var sentiment = Sentiment.getInstance();

        /*
         * This is the main loop that runs the scraper and sentiment analysis
         * It will run until the program is terminated
         */
        list.forEach(scraper -> executors.submit(() -> {
            try
            {
                var scraped = scraper.scrape(); // blocking call
                scraped.forEach(scrapedItem -> {
                    var sentimentResult = sentiment.detectSentiments(scrapedItem.data());
                    var keyPhrases = sentiment.detectAllKeyPhrases(scrapedItem.data());
                    logger.info(" \nName: {} \nURL: {} \nSentiment Text: {} \nSentiment Score: {} \nKey Phrases: {} \n", scraper.getName(), scraper.getScrapeUrl(), sentimentResult.getSentiment(), getHighestSentimentScore(sentimentResult.getSentimentScore()), keyPhrases.stream().map(keyPhrase -> "%s: %f".formatted(keyPhrase.getText(), keyPhrase.getScore())).collect(Collectors.joining(", ")));
                    generator.getSiteNames().add(scraper.getName());
                    generator.getSiteLinks().add(scraper.getScrapeUrl());
                    generator.getSiteSentiments().add(sentimentResult.getSentiment());
                    generator.getConfidence().add(getHighestSentimentScore(sentimentResult.getSentimentScore()));
                    generator.getKeywords().add( keyPhrases.stream().map(keyPhrase -> "%s".formatted(keyPhrase.getText())).collect(Collectors.joining(", ")));

                });
            }
            catch (Exception e)
            {
                logger.error("Error has occurred. It is probably because you didnt configure your keys in config.properties", e);
            }
        }));

        // terminates the executor service and waits for all threads to finish before exiting the program

        executors.shutdown();
        executors.awaitTermination(20, TimeUnit.SECONDS);
        generator.generateReport();


    }


    /**
     * Returns the highest sentiment score from the list of sentiment scores
     * @param sentimentScore an object containing the sentiment scores
     * @return the highest sentiment score from the list of sentiment scores as a float
     */
    private static float getHighestSentimentScore(SentimentScore sentimentScore)
    {
     return Stream.of(sentimentScore.getNegative(), sentimentScore.getNeutral(), sentimentScore.getPositive())
             .max(Float::compareTo)
             .orElseThrow(() -> new RuntimeException("Some how we got a null optional float. This should never happen. Java is broken."));
    }


}
