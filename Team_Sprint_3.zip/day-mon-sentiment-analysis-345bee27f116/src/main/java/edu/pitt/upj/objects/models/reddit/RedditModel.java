
package edu.pitt.upj.objects.models.reddit;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.processing.Generated;


public class RedditModel {

    private String kind;
    private Data data;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public String getKind() {
        return kind;
    }

    public void setKind(String kind) {
        this.kind = kind;
    }

    public RedditModel withKind(String kind) {
        this.kind = kind;
        return this;
    }

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }

    public RedditModel withData(Data data) {
        this.data = data;
        return this;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public RedditModel withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    public static RedditModel asModel(String json)
    {
        try
        {
            return new ObjectMapper().readValue(json, RedditModel.class);
        }
        catch (JsonProcessingException e)
        {
            return null;
        }
    }

}
