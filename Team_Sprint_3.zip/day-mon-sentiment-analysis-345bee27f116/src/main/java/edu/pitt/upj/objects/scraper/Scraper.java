package edu.pitt.upj.objects.scraper;

import okhttp3.*;
import org.jetbrains.annotations.Nullable;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public abstract class Scraper
{
    private final List<String> userAgents = List.of(

            "Mozilla/5.0 (Linux; Android 8.0.0; SM-G960F Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.84 Mobile Safari/537.36",
            "Mozilla/5.0 (Linux; Android 7.0; SM-G892A Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/60.0.3112.107 Mobile Safari/537.36",
            "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:15.0) Gecko/20100101 Firefox/15.0.1",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.246"
    );
    private final String name = this.getClass().getSimpleName();
    private String getRandomUserAgent() { return userAgents.get(ThreadLocalRandom.current().nextInt(userAgents.size())); }
    protected final Logger scraperLogger = LoggerFactory.getLogger(this.getClass());
    private final String scrapeUrl;
    protected String jsonUrl = "";

    public abstract List<ScraperDTO> scrape();

    protected Scraper(String scrapeUrl) { this.scrapeUrl = scrapeUrl; }


    /**
     * <strong>This method is blocking</strong>
     *
     * @return Document object of the url or null if there was an error
     *
     **/
    @Nullable
    public Document getDocument()
    {
        var userAgent = getRandomUserAgent();
        scraperLogger.info("Scraping url [{}] with User-Agent [{}] ", this.getScrapeUrl(), userAgent);
        try
        {
            return Jsoup.connect(this.getScrapeUrl())
                    .userAgent(userAgent)
                    .get();
        }
        catch (IOException e)
        {
            scraperLogger.error("Error getting document from url: {}", this.getScrapeUrl(), e);
            return null;
        }
    }

    /**
     * <strong>This method is blocking</strong>
     *
     * @param url The url of the website you wish to scrape
     * @return Document object of the url or null if there was an error
     *
     **/
    public Document getDocument(String url)
    {
        var userAgent = getRandomUserAgent();
        scraperLogger.info("Scraping url [{}] with User-Agent [{}] ", url, userAgent);
        try
        {
            return Jsoup.connect(url)
                    .userAgent(userAgent)
                    .get();
        }
        catch (IOException e)
        {
            scraperLogger.error("Error getting document from url: {}", this.getScrapeUrl(), e);
            return null;
        }
    }

    /**
     * <strong>This method is blocking</strong>
     *
     * @return The body of the url or null if there was an error
     */
    @Nullable
    public String getBody()
    {
        var userAgent = getRandomUserAgent();
        scraperLogger.info("Scraping url [{}] with User-Agent [{}] ", this.getJsonUrl(), userAgent);

        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .addHeader("User-Agent", userAgent)
                .url(this.getJsonUrl())
                .build();

        try (var response = client.newCall(request).execute())
        {
            var body = response.body();
            if (body != null)
            {
                var string = body.string();
                body.close();
                return string;
            }
            return null;
        }
        catch (IOException e)
        {
            scraperLogger.error("Error getting body from url: {}", this.getScrapeUrl(), e);
            return null;
        }
    }

    public String getScrapeUrl() { return scrapeUrl; }

    public String getName() { return name; }

    public String getJsonUrl() {
        return jsonUrl;
    }


}
