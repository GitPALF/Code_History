package edu.pitt.upj.objects.scraper.scrapers;

import edu.pitt.upj.objects.scraper.Scraper;
import edu.pitt.upj.objects.scraper.ScraperDTO;
import org.jsoup.nodes.Element;

import java.util.List;
import java.util.stream.Collectors;

public class WTAJScraper extends Scraper
{
    public WTAJScraper()
    {
        super("https://www.wearecentralpa.com/news/local-news/university-of-pittsburgh-at-johnstown-educators-to-discuss-covid-19-public-health-issues/");
    }

    @Override
    public List<ScraperDTO> scrape()
    {
        var document = getDocument(this.getScrapeUrl());
        if (document == null) return List.of();
        var elements = document.getElementsByClass("article-content article-body rich-text ");
        return List.of(new ScraperDTO(this.getScrapeUrl() ,elements.stream().map(Element::text).collect(Collectors.joining("\n"))));

    }
}
