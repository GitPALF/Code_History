
package edu.pitt.upj.objects.models.reddit;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class Gif {

    private Source__1 source;
    private List<Resolution__1> resolutions = null;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public Source__1 getSource() {
        return source;
    }

    public void setSource(Source__1 source) {
        this.source = source;
    }

    public Gif withSource(Source__1 source) {
        this.source = source;
        return this;
    }

    public List<Resolution__1> getResolutions() {
        return resolutions;
    }

    public void setResolutions(List<Resolution__1> resolutions) {
        this.resolutions = resolutions;
    }

    public Gif withResolutions(List<Resolution__1> resolutions) {
        this.resolutions = resolutions;
        return this;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Gif withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

}
