package edu.pitt.upj.objects.scraper.scrapers;

import edu.pitt.upj.objects.scraper.Scraper;
import edu.pitt.upj.objects.scraper.ScraperDTO;

import java.util.List;

public class StudentsReviewScraper extends Scraper
{

    public StudentsReviewScraper()
    {
        super("http://www.studentsreview.com/PA/UPJ_comments.html?page=2&d_school=University+of+Pittsburgh+Johnstown");
    }

    @Override
    public List<ScraperDTO> scrape()
    {


        var studentReviewDocumentTwo = getDocument();
        if (studentReviewDocumentTwo == null) return List.of();
        var negativeReviews = studentReviewDocumentTwo.getElementsByClass("negative reviewcomment").text();


        return List.of(
                new ScraperDTO(this.getScrapeUrl(), negativeReviews.replace("Email it! Save", "").replace("Rate this comment: Useless (1) (2) (3) (4) (5) Helpful Question Your Response/Question: To be informed when someone replies to your comment", ""))
        );
    }
}
