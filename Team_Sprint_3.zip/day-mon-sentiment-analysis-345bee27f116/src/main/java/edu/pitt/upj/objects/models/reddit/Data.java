
package edu.pitt.upj.objects.models.reddit;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;

public class Data {

    private Object after;
    private Integer dist;
    private String modhash;
    private Object geo_filter;
    private List<Child> children = null;
    private Object before;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public Object getAfter() {
        return after;
    }

    public void setAfter(Object after) {
        this.after = after;
    }

    public Data withAfter(Object after) {
        this.after = after;
        return this;
    }

    public Integer getDist() {
        return dist;
    }

    public void setDist(Integer dist) {
        this.dist = dist;
    }

    public Data withDist(Integer dist) {
        this.dist = dist;
        return this;
    }

    public String getModhash() {
        return modhash;
    }

    public void setModhash(String modhash) {
        this.modhash = modhash;
    }

    public Data withModhash(String modhash) {
        this.modhash = modhash;
        return this;
    }

    public Object getGeo_filter() {
        return geo_filter;
    }

    public void setGeo_filter(Object geo_filter) {
        this.geo_filter = geo_filter;
    }

    public Data withGeo_filter(Object geo_filter) {
        this.geo_filter = geo_filter;
        return this;
    }

    public List<Child> getChildren() {
        return children;
    }

    public void setChildren(List<Child> children) {
        this.children = children;
    }

    public Data withChildren(List<Child> children) {
        this.children = children;
        return this;
    }

    public Object getBefore() {
        return before;
    }

    public void setBefore(Object before) {
        this.before = before;
    }

    public Data withBefore(Object before) {
        this.before = before;
        return this;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Data withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

}
