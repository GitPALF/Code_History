package edu.pitt.upj.objects.scraper.scrapers;

import edu.pitt.upj.objects.scraper.Scraper;
import edu.pitt.upj.objects.scraper.ScraperDTO;
import org.jsoup.nodes.Element;

import java.util.List;
import java.util.stream.Collectors;

public class TribuneScraper extends Scraper
{

    public TribuneScraper()
    {
        super("https://www.tribdem.com/news/local_news/pitt-johnstown-students-faculty-staff-compliant-with-vaccine-mandate/article_318b3e78-8e8d-11ec-90e4-634f14aa9967.html");
    }

    @Override
    public List<ScraperDTO> scrape()
    {
        var document = getDocument();
        if (document == null) return List.of();
        var text = document.getElementsByClass("asset-content  subscriber-premium").text();
        return List.of(new ScraperDTO(this.getScrapeUrl(), text));

    }
}
