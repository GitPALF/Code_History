package edu.pitt.upj.objects.scraper.scrapers;

import edu.pitt.upj.objects.scraper.Scraper;
import edu.pitt.upj.objects.scraper.ScraperDTO;
import org.jsoup.nodes.Element;

import java.util.List;
import java.util.stream.Collectors;

public class PittScraper extends Scraper
{
    public PittScraper()
    {
        super("https://www.pitt.edu/pittwire/accolades-honors/pitt-johnstown-leed-recognition-john-p-murtha");
    }

    @Override
    public List<ScraperDTO> scrape()
    {
        var document = getDocument();
        if (document == null) return List.of();
        var text = document.getElementsByClass("content-well").stream().map(Element::text).collect(Collectors.joining());
        return List.of(new ScraperDTO(this.getScrapeUrl(), text));
    }
}
