package edu.pitt.upj.handlers;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import edu.pitt.upj.objects.config.Config;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class ConfigHandler
{
    private static volatile ConfigHandler instance = null;
    private static final File CONFIG_FILE =  new File("config.properties");
    private final Config config;
    private final Logger logger = LoggerFactory.getLogger(ConfigHandler.class);

    private ConfigHandler()
    {
        initFile();
        this.config = loadValues();
        logger.info("Config loaded");
    }

    public static ConfigHandler getInstance()
    {
        if (instance == null)
        {
            synchronized (ConfigHandler.class)
            {
                if (instance == null)
                {
                    instance = new ConfigHandler();
                }
            }
        }
        return instance;
    }

    private void initFile()
    {
        try
        {
            CONFIG_FILE.createNewFile();
        }
        catch (Exception e)
        {
            logger.error("Error occurred while creating config file", e);
            System.exit(1);
        }
    }

    private Config loadValues()
    {
        var config = new Config();
        var om = new ObjectMapper();
        try
        {
            var json = Files.readString(Path.of(String.valueOf(CONFIG_FILE)));

            if (json.isEmpty())
            {
                save(config);
                return config;
            }


            config = om.readValue(
                    json,
                    Config.class
            );


            return config;
        }
        catch (JsonProcessingException exception)
        {
            logger.error("Could not parse config. Loading default values", exception);
            save(config);
            return config;
        }
        catch (IOException exception)
        {
            logger.error("Error occurred while. loading the file", exception);
            save(config);
            return config;
        }
    }


    private void save(Config config)
    {
        var json = config.getAsJson();

        if (json.isBlank())
        {
            logger.error("Error occurred while attempting to process json");
            return;
        }

        try (var writer = new FileWriter(CONFIG_FILE))
        {
            writer.write(json);
            writer.flush();
        }
        catch (IOException exception)
        {
            logger.error("CONFIG ERROR HAS OCCURRED", exception);
        }
    }

    public Config getConfig()
    {
        return config;
    }

}
