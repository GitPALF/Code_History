
package edu.pitt.upj.objects.models.reddit;

import java.util.HashMap;
import java.util.Map;


public class Variants {

    private Gif gif;
    private Mp4 mp4;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public Gif getGif() {
        return gif;
    }

    public void setGif(Gif gif) {
        this.gif = gif;
    }

    public Variants withGif(Gif gif) {
        this.gif = gif;
        return this;
    }

    public Mp4 getMp4() {
        return mp4;
    }

    public void setMp4(Mp4 mp4) {
        this.mp4 = mp4;
    }

    public Variants withMp4(Mp4 mp4) {
        this.mp4 = mp4;
        return this;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Variants withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

}
