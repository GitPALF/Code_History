
package edu.pitt.upj.objects.models.reddit;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class Poll_data {

    private Object prediction_status;
    private Object total_stake_amount;
    private Long voting_end_timestamp;
    private List<Option> options = null;
    private Object vote_updates_remained;
    private Boolean is_prediction;
    private Object resolved_option_id;
    private Object user_won_amount;
    private Object user_selection;
    private Integer total_vote_count;
    private Object tournament_id;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public Object getPrediction_status() {
        return prediction_status;
    }

    public void setPrediction_status(Object prediction_status) {
        this.prediction_status = prediction_status;
    }

    public Poll_data withPrediction_status(Object prediction_status) {
        this.prediction_status = prediction_status;
        return this;
    }

    public Object getTotal_stake_amount() {
        return total_stake_amount;
    }

    public void setTotal_stake_amount(Object total_stake_amount) {
        this.total_stake_amount = total_stake_amount;
    }

    public Poll_data withTotal_stake_amount(Object total_stake_amount) {
        this.total_stake_amount = total_stake_amount;
        return this;
    }

    public Long getVoting_end_timestamp() {
        return voting_end_timestamp;
    }

    public void setVoting_end_timestamp(Long voting_end_timestamp) {
        this.voting_end_timestamp = voting_end_timestamp;
    }

    public Poll_data withVoting_end_timestamp(Long voting_end_timestamp) {
        this.voting_end_timestamp = voting_end_timestamp;
        return this;
    }

    public List<Option> getOptions() {
        return options;
    }

    public void setOptions(List<Option> options) {
        this.options = options;
    }

    public Poll_data withOptions(List<Option> options) {
        this.options = options;
        return this;
    }

    public Object getVote_updates_remained() {
        return vote_updates_remained;
    }

    public void setVote_updates_remained(Object vote_updates_remained) {
        this.vote_updates_remained = vote_updates_remained;
    }

    public Poll_data withVote_updates_remained(Object vote_updates_remained) {
        this.vote_updates_remained = vote_updates_remained;
        return this;
    }

    public Boolean getIs_prediction() {
        return is_prediction;
    }

    public void setIs_prediction(Boolean is_prediction) {
        this.is_prediction = is_prediction;
    }

    public Poll_data withIs_prediction(Boolean is_prediction) {
        this.is_prediction = is_prediction;
        return this;
    }

    public Object getResolved_option_id() {
        return resolved_option_id;
    }

    public void setResolved_option_id(Object resolved_option_id) {
        this.resolved_option_id = resolved_option_id;
    }

    public Poll_data withResolved_option_id(Object resolved_option_id) {
        this.resolved_option_id = resolved_option_id;
        return this;
    }

    public Object getUser_won_amount() {
        return user_won_amount;
    }

    public void setUser_won_amount(Object user_won_amount) {
        this.user_won_amount = user_won_amount;
    }

    public Poll_data withUser_won_amount(Object user_won_amount) {
        this.user_won_amount = user_won_amount;
        return this;
    }

    public Object getUser_selection() {
        return user_selection;
    }

    public void setUser_selection(Object user_selection) {
        this.user_selection = user_selection;
    }

    public Poll_data withUser_selection(Object user_selection) {
        this.user_selection = user_selection;
        return this;
    }

    public Integer getTotal_vote_count() {
        return total_vote_count;
    }

    public void setTotal_vote_count(Integer total_vote_count) {
        this.total_vote_count = total_vote_count;
    }

    public Poll_data withTotal_vote_count(Integer total_vote_count) {
        this.total_vote_count = total_vote_count;
        return this;
    }

    public Object getTournament_id() {
        return tournament_id;
    }

    public void setTournament_id(Object tournament_id) {
        this.tournament_id = tournament_id;
    }

    public Poll_data withTournament_id(Object tournament_id) {
        this.tournament_id = tournament_id;
        return this;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Poll_data withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

}
